package mvc;

public interface MovieF {
	public String getTitle();
	public int getYear();
	public String getGenre();
	public String getDescription();
	public void setTitle(String title);
	public void setYear(int year);
	public void setGenre(String genre);
	public void setDescription(String description);
}

